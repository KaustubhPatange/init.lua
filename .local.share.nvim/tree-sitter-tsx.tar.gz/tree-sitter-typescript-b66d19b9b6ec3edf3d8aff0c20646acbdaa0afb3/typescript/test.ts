type a = readonly b[][];
