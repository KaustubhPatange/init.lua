---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--
     The tree-sitter-typescript project is a TypeScript and TSX parser only.
     How can we improve it?
-->
