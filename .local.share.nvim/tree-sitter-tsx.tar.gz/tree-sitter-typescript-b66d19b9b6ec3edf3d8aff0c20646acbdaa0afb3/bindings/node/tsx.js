module.exports = require('./index').tsx;
