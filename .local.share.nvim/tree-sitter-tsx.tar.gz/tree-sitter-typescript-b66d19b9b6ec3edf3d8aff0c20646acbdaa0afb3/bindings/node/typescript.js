module.exports = require('./index').typescript;
